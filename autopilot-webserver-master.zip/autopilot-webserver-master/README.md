#shellscript - by OmTegar

===========================================================================

Hay Semuanya Shell Script ini berkaitan dengan Reposiroty https://github.com/OmTegar/web-dinamis-produktif 
script ini bertujuan untuk melakukan konfigurasi webserver otomatis menggunakan shell script. 
untuk cara penggunaan nya silahkan kalian remote untuk instance yang kalian gunakan. 
disini saya menggunakan OS ubuntu 😎

===========================================================================

Pertama-tama silahkan login sebagai administrator dengan mengetikkan <br>
<code>sudo su</code><br>
Selanjutnya buat file ubuntu.sh <br>
<code>nano ubuntu.sh</code><br>
Selanjutnya kalian ubah terlebih dahulu koneksi RDS nya di line 29 dan 41, lalu simpan file nya.
Ubah chmod file ubuntu.sh dengan cara<br>
<code>chmod +x ubuntu.sh</code><br>
Lalu Running Script nya 😈😈😈😈<br>
<code>sudo ./ubuntu.sh</code><br>
Proses Installasi selesai , webserver siap di gunakan

===========================================================================

terimakasih banyak atas perhatiannya.
- OmTegar 

===========================================================================